<?php $__env->startSection('content'); ?>

    <div  class='login' dir="rtl" style="text-align: right">
        <form method="POST" action="<?php echo e(route('login')); ?>">
            <?php echo csrf_field(); ?>
        <h2>تسجيل الدخول</h2>
            <div class=" row">

            <input class="<?php echo e($errors->has('email') ? ' is-invalid' : ''); ?>" name="email"  value="<?php echo e(old('email')); ?>" required autofocus placeholder='البريد الالكتروني او رقم الهاتف' type='text'>

            <?php if($errors->has('email')): ?>
                <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('email')); ?></strong>
                                    </span>
            <?php endif; ?>
            </div>
            <div class=" row">

            <input  class="<?php echo e($errors->has('password') ? ' is-invalid' : ''); ?>" name="password" placeholder='الرقم السري' type='password'>

            </div>
            <div class=" row">

            <input class='animated' type='submit' value='<?php echo e(__('تسجيل الدخول')); ?>'>
            </div>
        </form>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.webLayouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /* C:\xampp\htdocs\wallet\resources\views/auth/login.blade.php */ ?>