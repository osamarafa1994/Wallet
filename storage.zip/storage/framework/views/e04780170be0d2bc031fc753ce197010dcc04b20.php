<style>
    .trans-form{
        background-color: white !important;
        margin: 6%;
        padding: 5%;
    }
    .prov-pho{
        width: 7%;
    }
</style>
<?php $__env->startSection('content'); ?>

    <section>
        <!--for demo wrap-->
        <h1>اخير العمليات التي تم تحويلها</h1>
        <div class="tbl-header">
            <table cellpadding="0" cellspacing="0" border="0">
                <thead>
                <tr>
                    <th scope="col">اسم المستخدم</th>
                    <th scope="col">الرقم المحول اليه</th>
                    <th scope="col">المبلغ</th>
                    <th scope="col">الحالة</th>
                </tr>
                </thead>
            </table>
        </div>
        <div class="tbl-content">
            <table cellpadding="0" cellspacing="0" border="0">
                <tbody>
                <?php if(!empty($processes) && $processes != null && isset($processes)): ?>
                    <?php $__currentLoopData = $processes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$process): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                        <tr style="background-color:
<?php if($process->suspend == 1) { ?>
darkred;
<?php }elseif ($process->suspend == 2){?>
    green;
   <?php  } ?>
                            ">
                            <td><?php echo e($process->customer->name); ?></td>
                            <td><?php echo e($process->to_phone); ?></td>
                            <td><?php echo e($process->value); ?>    جنية </td>
                            <td>
                                <?php if($process->suspend == 1) { ?>
                                    لم يتم التحويل
                                    <?php }elseif ($process->suspend == 2){?>
                                    تم التحويل

                                <?php  } ?>
                            </td>

                        </tr>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>

                </tbody>
            </table>

        </div>
    </section>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.adminLayouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /* C:\xampp\htdocs\wallet\resources\views/admin/customers/transforms.blade.php */ ?>