<style>
    .trans-form{
        background-color: white !important;
        margin: 6%;
        padding: 5%;
    }
    .prov-pho{
        width: 7%;
    }
</style>
<?php $__env->startSection('content'); ?>

    <section>
        <!--for demo wrap-->
        <h1>جميع العمليات لدينا</h1>
        <div class="tbl-header">
            <table cellpadding="0" cellspacing="0" border="0">
                <thead>
                <tr>
                    <th scope="col">اسم العميل</th>
                    <th scope="col">رقم الهاتف</th>
                    <th scope="col">الرصيد</th>
                    <th scope="col">الاجراء</th>
                </tr>
                </thead>
            </table>
        </div>
        <div class="tbl-content">
            <table cellpadding="0" cellspacing="0" border="0">
                <tbody>
                <?php if(!empty($customers) && $customers != null && isset($customers)): ?>
                    <?php $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                        <tr >
                            <td ><a style="color: white !important;" href="<?php echo e(asset("admin/user/$user->id")); ?>"><?php echo e($user->name); ?></a></td>
                            <td><?php echo e($user->phone); ?></td>
                            <td><?php echo e($user->wallet_value); ?>    جنية </td>
                            <td> </td>


                        </tr>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>

                </tbody>
            </table>

        </div>
    </section>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.adminLayouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /* E:\xampp\htdocs\walletLast\resources\views/admin/customers/allCustomers.blade.php */ ?>