<?php $__env->startSection('content'); ?>


    <section>
    <!--for demo wrap-->
    <h1>قائمة الطلبات للتحويل</h1>
    <div class="tbl-header">
        <table cellpadding="0" cellspacing="0" border="0">
            <thead>
            <tr>
                <th>اسم المستخدم</th>
                <th>الرقم المراد التحويل اليه</th>
                <th>المبلغ</th>
                <th>الرصيد المتاح</th>
                <th></th>
            </tr>
            </thead>
        </table>
    </div>
    <div class="tbl-content">
        <table cellpadding="0" cellspacing="0" border="0">
            <tbody>
            <?php if(count($processes) == 0): ?>
                <tr>
                    <td colspan="5" style="text-align: center" bgcolor="#ff4110">لا يوجد طلبات تحويل</td>

                </tr>
            <?php elseif(!empty($processes) && $processes != null && isset($processes)): ?>
            <?php $__currentLoopData = $processes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$process): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <tr>
                    <td><?php echo e($process->customer->name); ?></td>
                    <td><?php echo e($process->to_phone); ?></td>
                    <td><?php echo e($process->value); ?>    جنية </td>
                    <td><?php echo e($process->customer->wallet->value); ?>    جنية </td>
                    <td>
                        <a href="#" class="text-success" data-toggle="modal" data-target="#exampleModal<?php echo e($process->id); ?>">
                            <li class="fa fa-check"></li>
                        </a>
                    </td>
                </tr>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            <?php endif; ?>

            </tbody>
        </table>

    </div>
</section>

<?php $__env->stopSection(); ?>


    <?php if(!empty($processes) && $processes != null && isset($processes)): ?>
        <?php $__currentLoopData = $processes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$process): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <!-- Modal -->
            <div class="modal fade modal-success" id="exampleModal<?php echo e($process->id); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                <div class="modal-dialog " role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title" id="exampleModalLabel">تنفيذ التحويل </h5>

                        </div>

                        <div class="modal-body">
                            <div class="">
                                <form action="action_page.php">
                                    <h1 class="mod-h1"><?php echo e($process->value); ?>  جنية</h1>
                                    <h1 class="mod-h1"><?php echo e($process->to_phone); ?></h1>


                                </form>
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button type="button"  class="btn btn-secondary  pull-left" data-dismiss="modal">اغلاق</button>
                            <a type="button" href="<?php echo e(asset("admin/wallet_update_add/{$process->id}/$process->value/{$process->customer->id}")); ?>" class="btn btn-danger  pull-left"> لم يتم التحويل </a>
                            <a type="button" href="<?php echo e(asset("admin/wallet_update_delete/{$process->id}/{$process->value}/{$process->customer->id}")); ?>" class="btn btn-primary  pull-left">تم التحويل  </a>
                        </div>
                    </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    <?php endif; ?>



<?php echo $__env->make('layouts.adminLayouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /* C:\xampp\htdocs\wallet\resources\views/admin/customers/index.blade.php */ ?>