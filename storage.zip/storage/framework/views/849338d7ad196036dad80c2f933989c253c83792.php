<div class='login' dir="rtl" style="text-align: right">
    <?php if(\Session::has('success')): ?>
        <div class="alert alert-success">
            <?php echo \Session::get('success'); ?>

        </div>
    <?php endif; ?>

        <form method="POST" action="<?php echo e(route('appcust.store')); ?>">
            <?php echo csrf_field(); ?>

        <h2>تسجيل مستخدم جديد</h2>
            <div class="row">
                <input name='name' class="<?php echo e($errors->has('name') ? ' is-invalid' : ''); ?>"   value="<?php echo e(old('name')); ?>" required placeholder='اسم المستخدم' type='text'>
                <?php if($errors->has('name')): ?>
                    <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($errors->first('name')); ?></strong>
                    </span>
                <?php endif; ?>
            </div>
            <div class="row">
                <input name='phone' placeholder='رقم الهاتف' class="<?php echo e($errors->has('phone') ? ' is-invalid' : ''); ?>"   value="<?php echo e(old('phone')); ?>" required  type='text'>
                <?php if($errors->has('phone')): ?>
                    <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($errors->first('phone')); ?></strong>
                    </span>
                <?php endif; ?>
            </div>
            <div class="row">
                <input name='personal_id' class="<?php echo e($errors->has('personal_id') ? ' is-invalid' : ''); ?>"   value="<?php echo e(old('personal_id')); ?>" placeholder='رقم البطاقة' type='text'>

                <?php if($errors->has('personal_id')): ?>
                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('personal_id')); ?></strong>
                                    </span>
                <?php endif; ?>
            </div>
            <div class="row">
                <input class='animated' type='submit' value='التسجيل'>

            </div>

    <a class='forgot' href='<?php echo e(asset('login')); ?>'>امتلك حساب بالفعل </a>
        </form>
</div>

<?php echo $__env->make('layouts.webLayouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /* C:\xampp\htdocs\wallet\resources\views/customersApplation/index.blade.php */ ?>