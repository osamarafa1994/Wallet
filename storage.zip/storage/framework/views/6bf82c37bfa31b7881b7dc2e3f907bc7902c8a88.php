<?php $__env->startSection('content'); ?>
    <style>

       .title{
           padding: 10px;
           background-color: #1b1e21;
           color: white;
           text-align: center;
           }

    </style>


<div class="trans-form">
    <?php if(\Session::has('success')): ?>
        <div class="alert alert-success">
            <?php echo \Session::get('success'); ?>

        </div>
    <?php endif; ?>

            


    <form method="post" action="<?php echo e(asset('admin/transformTo')); ?>" class="">
        <?php echo csrf_field(); ?>

        <div class="row">
            <input type="radio" name="network_type" value="vodafone" >vodafone <img src="<?php echo e(asset('assets/web_assets/img/voda.jpg')); ?>" alt="image" class="prov-pho"> <br>
            <input type="radio" name="network_type" value="etisalat" > etisalat<img src="<?php echo e(asset('assets/web_assets/img/etisalat.png')); ?>" alt="image" class="prov-pho">  <br>
            <input type="radio" name="network_type" value="orange">orange <img src="<?php echo e(asset('assets/web_assets/img/orang.png')); ?>" alt="image" class="prov-pho">  <br>
            <input type="radio" name="network_type" value="we">we<img src="<?php echo e(asset('assets/web_assets/img/we.jpg')); ?>" alt="image" class="prov-pho"> <br><br>
        <?php if($errors->has('network_type')): ?>
                <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($errors->first('network_type')); ?></strong>
                    </span>
            <?php endif; ?>
        </div>
        <div class="row">

        ادخل الرقم<br>
        <input type="text" name="to_phone"><br>
            <?php if($errors->has('to_phone')): ?>
                <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($errors->first('to_phone')); ?></strong>
                    </span>
            <?php endif; ?>
        </div>
        <div class="row">

        ادخل المبلغ:<br>
        <input type="text" name="value"><br><br>
            <?php if($errors->has('network_type')): ?>
                <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($errors->first('value')); ?></strong>
                    </span>
            <?php endif; ?>
        </div>
        <div class="row">
            <input class='btn btn-primary' type='submit' value='ارسال'>
        </div>
    </form>
</div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.adminLayouts.appCustomer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /* C:\xampp\htdocs\wallet\resources\views/admin/customers/userCanTransform.blade.php */ ?>